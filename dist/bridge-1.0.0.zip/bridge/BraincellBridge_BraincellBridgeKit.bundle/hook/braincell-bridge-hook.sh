# braincell-bridge-hook.sh
#
# Registers this interactive shell with the local Braincell Bridge so the
# global hotkey overlay (and Claude Code's MCP) can route to this terminal.
#
# Usage — add one line to your ~/.zshrc or ~/.bashrc:
#
#     [ -f "/path/to/braincell-bridge-hook.sh" ] && \
#         source "/path/to/braincell-bridge-hook.sh"
#
# Behavior:
#   * Idempotent: if a session is already registered for this shell (BRIDGE_SESSION_ID
#     is set + still alive on the server), don't re-register.
#   * On source: POSTs /sessions, exports BRIDGE_SESSION_ID.
#   * On `cd`: PATCHes /sessions/<id> with the new projectPath so the popover label tracks.
#   * Background: heartbeats every 30s; re-registers on 404.
#   * On shell EXIT: DELETEs the session.
#
# Silent on success. Errors print one line to stderr. No deps beyond curl.
# Override the bridge port by exporting BRAINCELL_BRIDGE_PORT before sourcing.

# --- Config -----------------------------------------------------------------

# Port discovery: the bridge writes its actual listening port to a known file
# on startup. We prefer that over the env var / default because the bridge
# auto-bumps if 3457 is held by something else.
if [ -r /tmp/braincell-bridge.port ]; then
    BRIDGE_PORT=$(cat /tmp/braincell-bridge.port 2>/dev/null)
fi
[ -z "$BRIDGE_PORT" ] && BRIDGE_PORT="${BRAINCELL_BRIDGE_PORT:-3457}"
export BRAINCELL_BRIDGE_PORT="$BRIDGE_PORT"

_braincell_bridge_url() {
    printf 'http://127.0.0.1:%s%s' "$BRIDGE_PORT" "$1"
}

# --- Register (idempotent) --------------------------------------------------

_braincell_bridge_register() {
    # Only register interactive shells.
    case "$-" in
        *i*) ;;
        *) return 0 ;;
    esac

    # Idempotency: if we already have a session id and it's still alive, no-op.
    if [ -n "$BRIDGE_SESSION_ID" ]; then
        _bb_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 \
            -X POST "$(_braincell_bridge_url "/sessions/$BRIDGE_SESSION_ID/heartbeat")" 2>/dev/null)
        if [ "$_bb_code" = "200" ]; then
            unset _bb_code
            return 0
        fi
        unset _bb_code BRIDGE_SESSION_ID
    fi

    _bb_pid=$$
    _bb_tty=$(tty 2>/dev/null)
    [ -z "$_bb_tty" ] && _bb_tty="unknown"
    _bb_term="${TERM_PROGRAM:-unknown}"
    _bb_proj="$PWD"
    _bb_title=""

    # "Bind with new terminal" flow: bridge drops a .bridge-pending-bind
    # marker in the cwd it spawned this terminal at. Read + delete it; the
    # contents are a JSON-encoded Target enum we forward inline so the
    # bridge auto-binds the session right after registration. No file = no
    # pending bind, regular registration.
    _bb_pending=""
    if [ -f "$PWD/.bridge-pending-bind" ]; then
        _bb_pending=$(cat "$PWD/.bridge-pending-bind" 2>/dev/null)
        rm -f "$PWD/.bridge-pending-bind" 2>/dev/null
    fi

    # Build JSON payload by hand (avoid jq). Pending-bind JSON is embedded
    # as a string field — bridge re-decodes it server-side via JSONDecoder.
    # We escape its " characters so the outer JSON parses cleanly.
    if [ -n "$_bb_pending" ]; then
        _bb_pending_esc=$(printf '%s' "$_bb_pending" | sed 's/"/\\"/g')
        _bb_payload=$(printf '{"pid":%s,"tty":"%s","terminalApp":"%s","windowTitle":"%s","projectPath":"%s","pendingBind":"%s"}' \
            "$_bb_pid" "$_bb_tty" "$_bb_term" "$_bb_title" "$_bb_proj" "$_bb_pending_esc")
    else
        _bb_payload=$(printf '{"pid":%s,"tty":"%s","terminalApp":"%s","windowTitle":"%s","projectPath":"%s"}' \
            "$_bb_pid" "$_bb_tty" "$_bb_term" "$_bb_title" "$_bb_proj")
    fi

    _bb_resp=$(curl -fsS --max-time 2 \
        -H 'Content-Type: application/json' \
        -X POST \
        --data "$_bb_payload" \
        "$(_braincell_bridge_url /sessions)" 2>/dev/null)
    _bb_rc=$?

    if [ $_bb_rc -ne 0 ] || [ -z "$_bb_resp" ]; then
        printf 'braincell-bridge: register failed (port %s)\n' "$BRIDGE_PORT" >&2
        unset _bb_pid _bb_tty _bb_term _bb_proj _bb_title _bb_payload _bb_resp _bb_rc
        return 1
    fi

    _bb_id=$(printf '%s' "$_bb_resp" | sed -n 's/.*"id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
    if [ -z "$_bb_id" ]; then
        printf 'braincell-bridge: malformed register response\n' >&2
        unset _bb_pid _bb_tty _bb_term _bb_proj _bb_title _bb_payload _bb_resp _bb_rc _bb_id
        return 1
    fi

    BRIDGE_SESSION_ID="$_bb_id"
    export BRIDGE_SESSION_ID

    # Streaming intent overlay: route Anthropic API through the bridge's
    # local proxy so it can parse the SSE stream and surface tool_use
    # composition in the overlay before the actual MCP dispatch fires.
    # OFF by default — the perceptual win is small and a proxy crash
    # cascades to Chrome (Chrome is a session descendant of the bridge,
    # gets SIGHUP'd if bridge dies). Opt in by exporting
    # `BRIDGE_STREAM_OVERLAY=1` BEFORE sourcing this hook (e.g. in
    # ~/.zshrc) — the substantive Phase 4.5 wins (parallel-call hints,
    # scene injection, Vision-augmented find, live reload) are all
    # active regardless of this flag. proxy_port=0 means proxy isn't
    # ready yet — skip; Claude Code falls back to direct api.anthropic.com.
    if [ "${BRIDGE_STREAM_OVERLAY:-0}" = "1" ]; then
        _bb_proxy_port=$(printf '%s' "$_bb_resp" | sed -n 's/.*"proxy_port"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p')
        if [ -n "$_bb_proxy_port" ] && [ "$_bb_proxy_port" != "0" ]; then
            ANTHROPIC_BASE_URL="http://127.0.0.1:${_bb_proxy_port}/sess/${_bb_id}"
            export ANTHROPIC_BASE_URL
        fi
    fi

    unset _bb_pid _bb_tty _bb_term _bb_proj _bb_title _bb_payload _bb_resp _bb_rc _bb_id _bb_proxy_port _bb_pending _bb_pending_esc
    return 0
}

# --- cd-aware projectPath update --------------------------------------------

_braincell_bridge_patch_pwd() {
    [ -z "$BRIDGE_SESSION_ID" ] && return 0
    _bb_payload=$(printf '{"projectPath":"%s"}' "$PWD")
    _bb_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 -X PATCH \
        -H 'Content-Type: application/json' \
        --data "$_bb_payload" \
        "$(_braincell_bridge_url "/sessions/$BRIDGE_SESSION_ID")" 2>/dev/null)
    # Bridge restart (or Reset all) wipes our session — recover from the
    # interactive shell instead of from the disowned heartbeat subshell.
    if [ "$_bb_code" = "404" ]; then
        unset BRIDGE_SESSION_ID
        _braincell_bridge_register >/dev/null 2>&1 || :
    fi
    unset _bb_payload _bb_code
}

# --- Heartbeat loop ---------------------------------------------------------

_braincell_bridge_heartbeat_loop() {
    # First arg = parent shell PID. We exit if the parent is gone — otherwise a
    # disowned subshell can outlive its terminal and re-register orphan sessions.
    _bb_parent=$1
    while :; do
        sleep 30
        kill -0 "$_bb_parent" 2>/dev/null || exit 0
        [ -z "$BRIDGE_SESSION_ID" ] && exit 0

        _bb_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 \
            -X POST "$(_braincell_bridge_url "/sessions/$BRIDGE_SESSION_ID/heartbeat")" 2>/dev/null)

        # Bridge restarted or Reset all → our session is gone. EXIT instead
        # of re-registering — re-registering from a disowned subshell creates
        # phantom sessions (tty="not a tty", no associated terminal window).
        # The interactive parent shell will re-register itself on its next
        # precmd / chpwd via the recovery hooks.
        if [ "$_bb_code" = "404" ]; then
            exit 0
        fi
        unset _bb_code
    done
}

# --- Unregister on exit -----------------------------------------------------

_braincell_bridge_unregister() {
    [ -z "$BRIDGE_SESSION_ID" ] && return 0
    curl -fsS --max-time 2 -X DELETE \
        "$(_braincell_bridge_url "/sessions/$BRIDGE_SESSION_ID")" >/dev/null 2>&1 || :
    unset BRIDGE_SESSION_ID
}

trap '_braincell_bridge_unregister' EXIT

# --- Kickoff + cd hook ------------------------------------------------------

_braincell_bridge_register

# --- claude wrapper: auto-pass --no-chrome when bridge is active ------------
#
# Claude Code auto-installs `claude-in-chrome`, a third-party MCP that competes
# with the bridge for browser-control intents like "open website." When a bridge
# session is active for this terminal, transparently add `--no-chrome` to every
# `claude` invocation so the bridge wins by default. Bypass with `command claude`
# or `\claude` if you ever want claude-in-chrome back for a one-off.
#
# Mirrors how Braincell-the-IDE launches its terminals (always with --no-chrome).
claude() {
    if [ -n "$BRIDGE_SESSION_ID" ]; then
        command claude --no-chrome "$@"
    else
        command claude "$@"
    fi
}

# Recovery hook: keep this shell's session live across bridge restarts.
# Fires on every prompt. Two cases:
#   1. BRIDGE_SESSION_ID unset → register from scratch.
#   2. BRIDGE_SESSION_ID set but stale (bridge restarted while we held the
#      old id) → probe with a fast heartbeat; on 404 unset and re-register.
# Cost: one ~5ms localhost POST per prompt when bridge is up. If bridge is
# down, curl --max-time 1 caps the wait — and connection-refused returns
# instantly anyway, so no perceptible lag at the prompt.
_braincell_bridge_recover() {
    if [ -z "$BRIDGE_SESSION_ID" ]; then
        _braincell_bridge_register >/dev/null 2>&1 || :
        return
    fi
    _bb_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 1 \
        -X POST "$(_braincell_bridge_url "/sessions/$BRIDGE_SESSION_ID/heartbeat")" 2>/dev/null)
    if [ "$_bb_code" = "404" ]; then
        unset BRIDGE_SESSION_ID
        _braincell_bridge_register >/dev/null 2>&1 || :
    fi
    unset _bb_code
}

# Wire cd-aware patch + per-prompt recovery into both zsh and bash without
# touching the user's PROMPT / PROMPT_COMMAND.
if [ -n "$ZSH_VERSION" ]; then
    autoload -Uz add-zsh-hook 2>/dev/null && {
        add-zsh-hook chpwd _braincell_bridge_patch_pwd
        add-zsh-hook precmd _braincell_bridge_recover
    }
elif [ -n "$BASH_VERSION" ]; then
    if ! declare -f _braincell_bridge_orig_cd >/dev/null 2>&1; then
        eval "_braincell_bridge_orig_cd() { builtin cd \"\$@\"; }"
        cd() { _braincell_bridge_orig_cd "$@" && _braincell_bridge_patch_pwd; }
    fi
    # PROMPT_COMMAND: append, don't overwrite.
    case "$PROMPT_COMMAND" in
        *_braincell_bridge_recover*) ;;
        *) PROMPT_COMMAND="${PROMPT_COMMAND:+$PROMPT_COMMAND;}_braincell_bridge_recover" ;;
    esac
fi

# Background heartbeat — pass our PID so the loop dies if we do.
# Wrapped in a subshell so the user's interactive shell never sees the
# "[N] PID" job-started notice. The outer subshell forks the loop in
# the background and exits immediately; the parent only sees the
# subshell's exit (silent, no job entry). zsh's `&!` would also work
# (background + disown in one) but the subshell approach is portable
# across bash/zsh.
( _braincell_bridge_heartbeat_loop $$ </dev/null >/dev/null 2>&1 & )
