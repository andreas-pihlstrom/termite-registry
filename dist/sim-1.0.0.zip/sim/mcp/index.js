#!/usr/bin/env node

/**
 * termite-sim — MCP stdio server for the sim plugin.
 *
 * The iOS Simulator dev loop for an agent building a Swift app, beside the
 * conversation: build + install + launch (xcodebuild + xcrun simctl),
 * screenshot the running app, read its logs, tap it, open deep links. When
 * the project is Injection-ready (krzysztofzablocki/Inject + InjectionIII),
 * small edits HOT-RELOAD into the running app — the agent just edits a file
 * and re-screenshots; no rebuild.
 *
 * Install: claude mcp add termite-sim -- node ~/.config/termite/plugins/sim/mcp/index.js
 */

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');

const MCP_SERVER_NAME = 'termite-sim';
const DISCOVERY_FILE = path.join(os.homedir(), '.config', 'termite', 'sim-api.json');
const DEFAULT_PORT = 4700;

let endpoint = null;
function resolveEndpoint() {
  if (process.env.TERMITE_SIM_PORT) {
    return { port: parseInt(process.env.TERMITE_SIM_PORT, 10), token: process.env.TERMITE_SIM_TOKEN || null };
  }
  try { const j = JSON.parse(fs.readFileSync(DISCOVERY_FILE, 'utf8')); if (j.port) return { port: j.port, token: j.token || null }; } catch {}
  return { port: DEFAULT_PORT, token: null };
}

const TOOLS = [
  { name: 'devices', description: 'List available iOS simulators (name, udid, state, runtime), booted ones first', inputSchema: { type: 'object', properties: {} } },
  { name: 'boot', description: 'Boot a simulator and dock its window into termite. Default: a booted one, else the first iPhone.', inputSchema: { type: 'object', properties: { device: { type: 'string', description: 'Device name or udid' } } } },
  { name: 'build', description: 'Build a scheme for the simulator (xcodebuild). Returns the built .app path and bundle id, or the compile errors.', inputSchema: { type: 'object', properties: { project: { type: 'string', description: 'Path to .xcodeproj' }, workspace: { type: 'string', description: 'Path to .xcworkspace (alternative to project)' }, scheme: { type: 'string' }, configuration: { type: 'string', description: 'Debug (default) or Release' } }, required: ['scheme'] } },
  { name: 'run', description: 'The core loop: build → install → launch → dock the Simulator → screenshot. Use this to see the app you are building. After it, if the project is Injection-ready, small edits hot-reload — just re-screenshot instead of running again.', inputSchema: { type: 'object', properties: { project: { type: 'string' }, workspace: { type: 'string' }, scheme: { type: 'string' }, configuration: { type: 'string' } }, required: ['scheme'] } },
  { name: 'screenshot', description: 'Screenshot the booted simulator at device resolution (no Screen Recording permission needed)', inputSchema: { type: 'object', properties: {} } },
  { name: 'logs', description: 'Recent unified-log lines for the running app (its own process)', inputSchema: { type: 'object', properties: { bundleId: { type: 'string', description: 'Defaults to the last app you ran' }, tail: { type: 'number' } } } },
  { name: 'tap', description: 'Tap the docked simulator at a point (in screen points within the simulator window). For element-level taps by label, add WebDriverAgent (see the plugin README).', inputSchema: { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' } }, required: ['x', 'y'] } },
  { name: 'openurl', description: 'Open a URL / deep link in the simulator', inputSchema: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] } },
  { name: 'push', description: 'Deliver a push notification (path to an APNs payload JSON)', inputSchema: { type: 'object', properties: { bundleId: { type: 'string' }, payload: { type: 'string' } }, required: ['payload'] } },
  { name: 'terminate', description: 'Terminate the running app', inputSchema: { type: 'object', properties: { bundleId: { type: 'string' } } } },
  { name: 'injection_status', description: 'Whether the project is wired for hot reload (krzysztofzablocki/Inject). If ready, edits update the running app without a rebuild.', inputSchema: { type: 'object', properties: { projectDir: { type: 'string' } } } },
];

async function callHttpApi(tool, args, isRetry = false) {
  if (!endpoint) endpoint = resolveEndpoint();
  const attempt = () => new Promise((resolve, reject) => {
    const postData = JSON.stringify({ tool, arguments: args });
    const headers = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(postData) };
    if (endpoint.token) headers['Authorization'] = `Bearer ${endpoint.token}`;
    const req = http.request({ hostname: '127.0.0.1', port: endpoint.port, path: '/execute', method: 'POST', headers },
      (res) => { let d = ''; res.on('data', c => d += c); res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve({ error: d }); } }); });
    req.on('error', reject);
    req.setTimeout(1_200_000, () => { req.destroy(); reject(new Error('timeout')); });   // builds are slow
    req.write(postData); req.end();
  });
  try { return await attempt(); }
  catch (e) {
    if (!isRetry) { endpoint = resolveEndpoint(); return callHttpApi(tool, args, true); }
    throw new Error(`termite-sim not reachable on port ${endpoint.port}: ${e.message} — is the Sim plugin enabled?`);
  }
}

function probeHealth() {
  endpoint = resolveEndpoint();
  return new Promise((resolve) => {
    const req = http.request({ hostname: '127.0.0.1', port: endpoint.port, path: '/health', method: 'GET' },
      (res) => { let c = ''; res.on('data', x => c += x); res.on('end', () => { try { resolve(JSON.parse(c)); } catch { resolve(null); } }); });
    req.on('error', () => resolve(null));
    req.setTimeout(500, () => { req.destroy(); resolve(null); });
    req.end();
  });
}

function handleInitialize(id) {
  return { jsonrpc: '2.0', id, result: { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: MCP_SERVER_NAME, version: '1.0.0' } } };
}
async function handleListTools(id) {
  const health = await probeHealth();
  return { jsonrpc: '2.0', id, result: { tools: health ? TOOLS : [] } };
}

const IMAGE_TOOLS = new Set(['run', 'screenshot', 'tap']);

async function handleCallTool(id, params) {
  const { name, arguments: args = {} } = params;
  try {
    const response = await callHttpApi(name, args || {});
    if (response.error) return { jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: `Error: ${response.error}` }] } };
    const result = response.result;
    let content = [];
    if (name === 'devices' && result?.devices) {
      content = [{ type: 'text', text: result.devices.map(d => `${d.state === 'Booted' ? '▶ ' : '  '}${d.name}  [${d.runtime}]  ${d.udid}`).join('\n') }];
    } else if (name === 'injection_status') {
      content = [{ type: 'text', text: `${result.ready ? 'HOT RELOAD READY' : 'no hot reload'} — ${result.reason}` }];
    } else if (name === 'logs') {
      content = [{ type: 'text', text: result?.logs || '(no logs)' }];
    } else {
      // Text summary minus the image blob, then the image if present.
      const { image, ...rest } = result || {};
      content = [{ type: 'text', text: JSON.stringify(rest, null, 2) }];
    }
    if (IMAGE_TOOLS.has(name) && result?.image) {
      content.push({ type: 'image', data: result.image, mimeType: `image/${result.format || 'png'}` });
    }
    return { jsonrpc: '2.0', id, result: { content } };
  } catch (error) {
    return { jsonrpc: '2.0', id, error: { code: -32000, message: error.message } };
  }
}

async function handleMessage(message) {
  const { method, id, params } = message;
  switch (method) {
    case 'initialize': return handleInitialize(id);
    case 'initialized': case 'notifications/initialized': case 'notifications/cancelled': return null;
    case 'tools/list': return handleListTools(id);
    case 'tools/call': return await handleCallTool(id, params);
    default: return id == null ? null : { jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } };
  }
}

function startServer() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
  let inFlight = 0, closed = false;
  const maybeExit = () => { if (closed && inFlight === 0) process.exit(0); };
  rl.on('line', async (line) => {
    inFlight++;
    try { const m = JSON.parse(line); const r = await handleMessage(m); if (r) console.log(JSON.stringify(r)); }
    catch { console.log(JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } })); }
    finally { inFlight--; maybeExit(); }
  });
  rl.on('close', () => { closed = true; maybeExit(); });
}
startServer();
